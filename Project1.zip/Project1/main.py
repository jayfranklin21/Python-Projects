# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

import csv
import matplotlib.pyplot as plt
import pprint as pp
fn=input('Enter a file name: \n')
try:
    fhand=open(fn)
    reader = csv.DictReader(fhand)
    d = {elem: [] for elem in reader.fieldnames}
    for row in reader:
        for key in d.keys():
            d[key].append(row[key])
except:
    print('try again')
    exit()
rcolor={}
for color in d['robot_color']:
    if color in rcolor:
        rcolor[color]+=1
    else:
        rcolor[color]=1
pp.pprint(rcolor)
first_name=[]
fcounter=0
for name in d['first_name']:
    first_name.append(name)
    fcounter+=len(name)
fnameAVG=fcounter/len(first_name)
print("Average first name length: ", fnameAVG)
last_name=[]
lcounter=0
for name in d['last_name']:
    last_name.append(name)
    lcounter+=len(name)
lnameAVG=lcounter/len(last_name)
print("Average last name length: ", lnameAVG)
f1_score=[]
f1Counter=0
for score in d['field_test_1']:
    f1_score.append(score)
    f1Counter+=int(score)
f1AVG=f1Counter/len(f1_score)
print('First Field Test Average: ', f1AVG)
f2_score=[]
f2Counter=0
for score in d['field_test_2']:
    f2_score.append(score)
    f2Counter+=int(score)
f2AVG=f2Counter/len(f2_score)
print("Second Field Test Average: ", f2AVG)
f3_score=[]
f3Counter=0
for score in d['field_test_3']:
    f3_score.append(score)
    f3Counter+=int(score)
f3AVG=f3Counter/len(f3_score)
print("Third Field Test Average: ", f3AVG)
max=0
maxid=0
for id in d['id']:
    avg=(int(f1_score[int(id)-1])+int(f2_score[int(id)-1])+int(f3_score[int(id)-1]))/3
    if avg>max:
        max = avg
        maxid=int(id)
print('Pilot #',maxid, first_name[int(maxid)-1], last_name[int(maxid)-1], 'had the highest average score: ',max)


















