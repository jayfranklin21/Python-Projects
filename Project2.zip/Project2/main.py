# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
#To make your coding experience easier, you need to first import the panda, pyplot and seaborn libraries
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb
#Open the file 'cereal.csv' and put the data in a pandas dataframe
fhand = open('C://Users//kjaso//Downloads//cereal.csv')
df=pd.read_csv(fhand)
#the '.mean()' method finds the mean of indicated column of the dataframe
mean_cal=df['calories'].mean()
mean_pro=df['protein'].mean()
mean_fat=df['fat'].mean()
mean_sod=df['sodium'].mean()
mean_fib=df['fiber'].mean()
mean_car=df['carbo'].mean()
mean_sug=df['sugars'].mean()
mean_wei=df['weight'].mean()
mean_cup=df['cups'].mean()
#the '.std()' method finds the standard deviation of the indicated column of the datadrame
std_cal=df['calories'].std()
std_pro=df['protein'].std()
std_fat=df['fat'].std()
std_sod=df['sodium'].std()
std_fib=df['fiber'].std()
std_car=df['carbo'].std()
std_sug=df['sugars'].std()
std_wei=df['weight'].std()
std_cup=df['cups'].std()
#'.idxmax()' finds the row number of the max value of the indicated column. Using this information,
#we can easily find the name of the cereal with the most of each substance
maxCalName=df['name'][df['calories'].idxmax()]
maxProName=df['name'][df['protein'].idxmax()]
maxFatName=df['name'][df['fat'].idxmax()]
maxSodName=df['name'][df['sodium'].idxmax()]
maxFibName=df['name'][df['fiber'].idxmax()]
#A count plot is the simplest way to count the elements in dataframe
mfrHist=sb.countplot(df['mfr'])
plt.savefig('mfrHist.png')
#displot of the calories over the mean
calDist=sb.distplot(df['calories'])
plt.savefig('calDist.png')
#boxplot of calories for each manufacturer
calBox=sb.boxplot(x='mfr', y='calories', hue='mfr', data=df)
plt.savefig('calBox.png')
#Opens a file to write all the data, and then writes the data to said file
file=open('cereal_data.txt', mode='w')
file.write('MEANS \n Calories: \t', mean_cal, '\n Protein: \t', mean_pro, '\n Fat: \t', mean_fat,
      '\n Sodium: \t', mean_sod, '\n Fiber: \t', mean_fib, '\n Carbohydrates: \t', mean_car,
      '\n Sugar: \t', mean_sug, '\n Weight: \t', mean_wei, '\n Cups: \t', mean_cup,
      '\nSTANDARD DEVIATIONS \n Calories: \t', std_cal, '\n Protein: \t', std_pro,
      '\n Fat: \t', std_fat, '\n Sodium: \t', std_sod, '\n Fiber: \t', std_fib,
      '\n Carbohydrates: \t', std_car, '\n Sugar: \t', std_sug, '\n Weight: \t', std_wei,
      '\n Cups: \t', std_cup, '\nMAXES \n Calories: \t', maxCalName, '\t', df['calories'].max(),
      '\n Protein: \t', maxProName, '\t', df['protein'].max(), '\n Fat: \t', maxFatName, '/t', df['fat'].max(),
      '\n Sodium: \t', maxSodName, '\t', df['sodium'].max(), '\n Fiber: \t', maxFibName, '\t', df['fiber'].max())
#Close the file
file.close()