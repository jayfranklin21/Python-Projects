import pandas as pd
pok=pd.read_csv('Pokemon.csv')
# Making a separate dataframe with only the 2 type pokemon
pokDrop=pok.dropna(axis=0, subset=['Type 2'], how='any')
# Type 2 is the variable we are testing the effect of, so it is set to x
xDrop=pokDrop['Type 2']
x=pok['Type 2']
# Since we cannot do regression or predictions with Categorical or String data we must use dummy data.
# This is easily accomplished using the get_dummies method.
x=pd.get_dummies(data=x, drop_first=True, prefix='Type 2')
pok=pok.join(x)
xDrop=pd.get_dummies(data=xDrop, drop_first=True, prefix='Type 2')
pokDrop=pokDrop.join(xDrop)
y=pok.drop(['Type 1', 'Name', 'Speed', 'Generation', 'Legendary'], axis=1)
yDrop=pokDrop.drop(['Type 1', 'Name', 'Speed', 'Generation', 'Legendary'], axis=1)
# We are testing the effect of the second type on strength in battle, so we should use both attack variables, both
# defense variables, HP and Total as dependent variables.
y1=pok['Attack']
y2=pok['Sp. Atk']
y3=pok['HP']
y4=pok['Defense']
y5=pok['Sp. Def']
y1Drop=pokDrop['Attack']
y2Drop=pokDrop['Sp. Atk']
y3Drop=pokDrop['HP']
y4Drop=pokDrop['Defense']
y5Drop=pokDrop['Sp. Def']
yTot=pok['Total']
yTotDrop=pokDrop['Total']
# The below function finds which legendary pokemon have no second type. This is because legendary pokemon are
# generally the strongest pokemon. When the function is run, it is found that every legendary pokemon has 2 types.
# This begins to prove that having 2 types increase attack strength.
def oneTypeLegend():
    for i in range(len(pok)):
        if pok['Legendary'][i]=='True' and pok['Type 2'][i]==None:
            print(pok['Name'][i])
# The following import statements give us all the tools we need to find the relationship between having a second
# type with attack and special attack.
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
scaler=StandardScaler()
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score
lm = LinearRegression()
# This function will use the data in a linear regression model by splitting it into training and test sets,
# transforming it with a scaler, fitting it with the model then plotting it, returning and r2_score.
def linModel(a, b):
    xtrain, xtest, ytrain, ytest = train_test_split(a, b)
    lm.fit(xtrain, ytrain)
    ypred=lm.predict(xtest)
    plt.scatter(ytest, ypred)
    plt.xlabel('True Value')
    plt.ylabel('Predicted Value')
    plt.show()
    return r2_score(ytest, ypred)
print('Linear Model, Type 2/Attack, null values included : \n', linModel(x, y1))
print('Linear Model, Type 2/Attack, no null values : \n', linModel(xDrop, y1Drop))
print('Linear Model, Type2/Special Attack, null values included : \n', linModel(x, y2))
print('Linear Model, Type2/Special Attack, no null values : \n', linModel(xDrop, y2Drop))
print('Linear Model, Type2/HP, null values included: \n', linModel(x, y3))
print('Linear Model, Type2/HP, no null values included: \n', linModel(xDrop, y3Drop))
print('Linear Model, Type2/Defense, null values included: \n', linModel(x, y4))
print('Linear Model, Type2/Defense, no null values included: \n', linModel(xDrop, y4Drop))
print('Linear Model, Type2/Special Defense, null values included: \n', linModel(x, y5))
print('Linear Model, Type2/Special Defense, no null values included: \n', linModel(xDrop, y5Drop))
print('Linear Model, Type2/Total, null values included: \n', linModel(x, yTot))
print('Linear Model, Type2/Total, no null values included: \n', linModel(xDrop, yTotDrop))
from sklearn.linear_model import LogisticRegression
log=LogisticRegression()
# This function will fit the data into a logistic regression in a similar fashion as the linear regression, but
# instead of using an r2_score it uses a log score to establish the effectiveness of the model.
def logModel(a, b):
    xtrain, xvalid, ytrain, yvalid = train_test_split(a, b)
    scaler.fit(xtrain)
    xtrain=scaler.transform(xtrain)
    xtest=scaler.transform(xvalid)
    log.fit(xtrain, ytrain)
    ypred=log.predict(xvalid)
    plt.scatter(yvalid, ypred)
    plt.xlabel('True Value')
    plt.ylabel('Predicted Value')
    plt.show()
    return log.score(xtrain, ytrain)
print('Logistic Model, Type 2/Attack, null values included: \n', logModel(x, y1))
print('Logistic Model, Type 2/Attack, no null values included: \n', logModel(xDrop, y1Drop))
print('Logistic Model, Type 2/Special Attack, null values not included: \n', logModel(x, y2))
print('Logistic Model, Type 2/Special Attack, no null values included: \n', logModel(xDrop, y2Drop))
print('Logistic Model, Type2/HP, null values included: \n', logModel(x, y3))
print('Logistic Model, Type2/HP, no null values included: \n', logModel(xDrop, y3Drop))
print('Logistic Model, Type2/Defense, null values included: \n', logModel(x, y4))
print('Logistic Model, Type2/Defense, no null values included: \n', logModel(xDrop, y4Drop))
print('Logistic Model, Type2/Special Defense, null values included: \n', logModel(x, y5))
print('Logistic Model, Type2/Special Defense, no null values included: \n', logModel(xDrop, y5Drop))
print('Logistic Model, Type2/Total, null values included: \n', logModel(x, yTot))
print('Logistic Model, Type2/Total, no null values included: \n'. logModel(xDrop, yTotDrop))